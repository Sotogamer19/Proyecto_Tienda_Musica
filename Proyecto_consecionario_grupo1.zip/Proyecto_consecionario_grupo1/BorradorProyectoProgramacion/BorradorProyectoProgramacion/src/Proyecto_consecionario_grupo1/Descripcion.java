/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Proyecto_consecionario_grupo1;

import javax.swing.JOptionPane;

/**
 *
 * @author jeanc
 */
// Clase enumerada para mostrar una pequeña descripción sobre cada uno de los modelos de los carros
public class Descripcion {
    public enum DescripcionAuto {
    MustangGT, Carrera, Camaro, Tucson, Vocho;
    }

    public void mostrarDescripcion() {
        DescripcionAuto d;
        
        //Se usa el try catch
        try {
            d = DescripcionAuto.valueOf(JOptionPane.showInputDialog(
                    "----- Ingrese el nombre del carro  -----\n"
                    + "MustangGT\n"
                    + "Carrera\n"
                    + "Camaro\n"
                    + "Tucson\n"
                    + "Vocho"));
            
            switch(d) {
                case MustangGT:
                    JOptionPane.showMessageDialog(null, "El Mustang GT es una variante del "
                            + "Ford Mustang, un automóvil deportivo icónico que ha desempeñado un papel importante\n"
                            + "en la historia del automovilismo estadounidense. El primer Ford Mustang fue presentado"
                            + "al público en el año 1964");
                break;
                
                case Carrera:
                    JOptionPane.showMessageDialog(null, "El Porsche 911 Carrera es parte de la "
                            + "línea de modelos 911 de Porsche, el cual es uno de los automóviles deportivos más \n"
                            + "emblemáticos y longevos en la historia del automovilismo. El primer diseño de este auto fue "
                            + "introducido en el año 1963");
                break;
                
                case Camaro:
                    JOptionPane.showMessageDialog(null, "El Camaro es un automóvil deportivo "
                            + "que ha sido parte importante de la cultura automotriz estadounidense desde su introducción."
                            + "\nFue presentado por primera vez como respuesta directa al éxito del Ford Mustang en el "
                            + "año 1966");
                break;
                
                case Tucson:
                    JOptionPane.showMessageDialog(null, "El Hyundai Tucson es un SUV"
                            + "(Sport Utility Vehicle / Vehículo Deportivo Utilitario) compacto que ha experimentado varias\n"
                            + "generaciones desde su introducción. Fue presentado por primera vez en el año 2004");
                break;
                
                case Vocho:
                    JOptionPane.showMessageDialog(null, "El Volkswagen Beetle, conocido "
                            + "coloquialmente como 'Vocho' en algunos lugares de América Latina y México,\n tiene una "
                            + "historia fascinante que abarca varias décadas desde su creación en el año 1930. El Vocho\n "
                            + "es un icono cultural debido a su diseño simple pero único y por su larga historia, estos\n "
                            + "factores han hecho que su legado perdure en la memoria de los aficionados de los carros");
                break;
            }
        //Se usa el catch para obtener una excepción, como un número
        } catch(Exception e) {
            JOptionPane.showMessageDialog(null, "Opción inválida");
        }
    }
}
