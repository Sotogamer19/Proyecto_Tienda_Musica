/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Proyecto_consecionario_grupo1;

import javax.swing.JOptionPane;

/**
 * Clase que representa un objeto Pago y contiene un método estático para realizar un pago.
 * @author jeanc
 */
public class Pago {
    public static void realizarPago(Carro carro, Cliente cliente) {
        // Si el cliente tiene historial de crédito se le aplica un descuento
        if(cliente.isHistorialCredito() == true) {
        // Calcular precio total con impuesto del 13%
        double precioSinIva = 10000;  // Ejemplo de precio sin IVA
        double iva = 0.13;
        double precioConIva = precioSinIva + (precioSinIva * iva);
        double descuento = precioConIva - 2000;
        
        // Mostrar recibo con descuento aplicado en un cuadro de dialogo
        JOptionPane.showMessageDialog(null, 
                "Recibo: " + (int) (Math.random() * 1000) + 1 +  "\n" 
                + "Cliente: " + cliente.getNombre() + "\n" 
                + "Edad: " + cliente.getEdad() + "\n" 
                + "ID: " + cliente.getId() + "\n" 
                + "Carro: " + carro.getMarca() + " " + carro.getModelo() + "\n" 
                + "Año: " + carro.getAño()+ "\n" 
                + "Placa: " + carro.getPlaca() + "\n" 
                + "Precio sin IVA: $" + precioSinIva + "\n"
                + "Precio con IVA: $" + precioConIva + "\n"
                + "Precio con descuento aplicado: $" + descuento);
        } else {
        // Calcular precio total con impuesto del 13%
        double precioSinIva = 10000;  // Ejemplo de precio sin IVA
        double iva = 0.13;
        double precioConIva = precioSinIva + (precioSinIva * iva);
        
        // Mostrar recibo en un cuadro de dialogo
        JOptionPane.showMessageDialog(null, 
                "Recibo: " + (int) (Math.random() * 1000) + 1 +  "\n" 
                + "Cliente: " + cliente.getNombre() + "\n" 
                + "Edad: " + cliente.getEdad() + "\n" 
                + "ID: " + cliente.getId() + "\n" 
                + "Carro: " + carro.getMarca() + " " + carro.getModelo() + "\n" 
                + "Año: " + carro.getAño()+ "\n" 
                + "Placa: " + carro.getPlaca() + "\n" 
                + "Precio sin IVA: $" + precioSinIva + "\n"
                + "Precio con IVA: $" + precioConIva);
        }
    }
}
