/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Proyecto_consecionario_grupo1;
/**
 *
 * @author jeanc
 */
import javax.swing.JOptionPane;

public class Cliente {

    // Atributos de la clase Cliente
    private String nombre;
    private int edad;
    private int id;
    private boolean historialCredito;

    //Constructor que inicializa las propiedades del cliente, con validación de edad
    public Cliente(String nombre, int edad, int id, boolean historialCredito) {
        this.nombre = nombre;
        this.edad = edad;
        this.id = id;
        this.historialCredito = historialCredito;
    }

    /*Metodo que se usa para seleccionar el carro que quiere el cliente, se guarda el carro del cliente o se hace 
    null si la selección es inválida. */
    public Carro seleccionarCarro(Carro[] carros) {
    int numeroCarro;
    String inputNumeroCarro = JOptionPane.showInputDialog("Ingrese el numero del carro que desea comprar:");
    try {
        numeroCarro = Integer.parseInt(inputNumeroCarro);
        if (numeroCarro >= 1 && numeroCarro <= carros.length) {
            return carros[numeroCarro - 1];
        } else {
            return null; // Devuelve null si la selección es fuera de rango
        }
    } catch (NumberFormatException e) {
        return null; // Devuelve null si la entrada no es un número
    }
}
    
    // Método que devuelve el nombre del cliente 
    public String getNombre() {
        return nombre;
    }

    // Método que devuelve la edad del cliente
    public int getEdad() {
        return edad;
    }

    // Método que devuelve el identificador del único del cliente
    public int getId() {
        return id;
    }

    /* Método que devuelve el historial crédito del cliente, true si el cliente tiene historial de crédito, false 
    de lo contrario */
    public boolean isHistorialCredito() {
        return historialCredito;
    }
    
    //Méotodo para verificar el beneficio del cliente
    public void verificarHistorialYBeneficio() {
        if (historialCredito) {
            JOptionPane.showMessageDialog(null, "¡Felicidades! Tiene un beneficio adicional por su historial de crédito.");
        } else {
            JOptionPane.showMessageDialog(null, "Gracias por su compra. No tiene beneficio adicional en este momento.");
        }
    }
}
