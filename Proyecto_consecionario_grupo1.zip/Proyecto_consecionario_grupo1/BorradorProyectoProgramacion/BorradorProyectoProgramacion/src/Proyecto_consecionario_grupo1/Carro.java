/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Proyecto_consecionario_grupo1;

import javax.swing.JOptionPane;

/**
 *Clase que representa un objeto Carro con propiedades como marca, modelo, año, placa y color. Además, 
 * incluye métodos para acceder y modificar estas propiedades, así como generar placas aleatorias y vizualizar 
 * carros disponibles.
 * 
 * @author jeanc
 */
public class Carro {

    // Atributos del Carro
    private String marca;
    private String modelo;
    private int año;
    private String placa;
    private String color;

    //Constructor lleno que inicializa las propiedades básicas del carro y genera automáticamente una placa. 
    public Carro(String marca, String modelo, int año, String color) {
        this.marca = marca;
        this.modelo = modelo;
        this.año = año;
        this.color = color;
        this.placa = generarPlaca();
    }

    //Métodos getters y setters para acceder y modificar las propiedades del carro.
    //Método que devuelve la marca del carro
    public String getMarca() {
        return marca;
    }

    // Método que establece la marca del carro
    public void setMarca(String marca) {
        this.marca = marca;
    }

    // Método que devuelve el modelo del carro
    public String getModelo() {
        return modelo;
    }

    // Método que establece el modelo del carro
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    // Método que devuelve el año de fabricación del carro
    public int getAño() {
        return año;
    }

    // Método que establece el año de fabricación del carro
    public void setAño(int año) {
        this.año = año;
    }

    // Método que devuelve la placa del carro
    public String getPlaca() {
        return placa;
    }

    // Método que devuelve el color del carro
    public String getColor() {
        return color;
    }

    // Metodo que establece el color del carro
    public void setColor(String color) {
        this.color = color;
    }
    
    // Método que se usar para crear una placa aleatoria
    private String generarPlaca() {

        StringBuilder placaGenerada = new StringBuilder();
        for (int i = 0; i < 3; i++) {
            char letra = (char) ('A' + Math.random() * ('Z' - 'A' + 1));
            placaGenerada.append(letra);
        }
        for (int i = 0; i < 3; i++) {
            int numero = (int) (0 + Math.random() * (9 - 0 + 1));
            placaGenerada.append(numero);
        }
        return placaGenerada.toString();
    }
}