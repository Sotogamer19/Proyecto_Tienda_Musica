    /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Proyecto_consecionario_grupo1;

/**
 * Clase principal que inicia la ejecución del programa.
 * No se utilizan argumentos de la línea de comandos (no se utilizan en este programa)
 * @author jeanc
 */
import javax.swing.JOptionPane;

public class Principal {

    public static void main(String[] args) {
        int opcion = 0;
        
        // Instancia de la clase Descripcion
        Descripcion d1 = new Descripcion();
        
        //Arreglo de la clase Carro para almacenar los carros disponibles
        Carro[] carrosDisponibles = new Carro[5];
        for(int i = 0; i < carrosDisponibles.length; i++) {
            carrosDisponibles[0] = new Carro("Marca" + " Ford", "Modelo" + " Mustang GT", 2023, "Color" + " Azul");
            carrosDisponibles[1] = new Carro("Marca" + " Porsche", "Modelo" + " 911 Carrera", 2022, "Color" + " Gris");
            carrosDisponibles[2] = new Carro("Marca" + " Chevrolet", "Modelo" + " Camaro", 2021, "Color" + " Amarillo");
            carrosDisponibles[3] = new Carro("Marca" + " Hyundai", "Modelo" + " Tucson", 2020, "Color" + " Rojo");
            carrosDisponibles[4] = new Carro("Marca" + " Volkswagen", "Modelo" + " Vocho", 2019, "Color" + " Rojo");
        }

        // Variables para almacenar el cliente actual y el carro seleccionado
        Cliente clienteActual = null;
        Carro carroSeleccionado = null;

        // Ciclo principal del programa
        do {
            // Menu principal 
            String input = JOptionPane.showInputDialog(
                    "----- Menú Principal -----\n"
                    + "1. Visualizar automóviles\n"
                    + "2. Seleccionar y comprar carro\n"
                    + "3. Realizar pago\n"
                    + "4. Salir\n"
                    + "Ingrese la opción deseada:");
            try {
                opcion = Integer.parseInt(input);
            } catch (NumberFormatException e) {
                opcion = 0; // Si la entrada no es un número válido, se establece la opción en 0.
            }
            
            // Se usa un switch para manejar las opciones del menú
            switch (opcion) {
                case 1:
                    // Si aún no ha seleccionado un carro, se muestra el catalogo completo
                    if(carroSeleccionado == null) {
                    // Se llama al metodo que llama a todos los carros disponibles
                    visualizarCatalogoCarros(carrosDisponibles);
                    // Se muestra una descripcion del auto
                    d1.mostrarDescripcion();
                    // Al haberse seleccionado un carro, no se muestra el carro seleccionado en el catalogo
                    } else {
                    // Se llama al metodo que sirve para mostrar todos los carros menos el carro elegido
                    VisualizarCarrosDisponibles(carrosDisponibles, carroSeleccionado.getAño());
                    }
                    break;
                case 2:
                    visualizarCatalogoCarros(carrosDisponibles);
    clienteActual = seleccionarCliente();
    if (clienteActual != null) {
        carroSeleccionado = clienteActual.seleccionarCarro(carrosDisponibles);
        if (carroSeleccionado != null) {
            JOptionPane.showMessageDialog(null, "Carro seleccionado con éxito.");
            auto_elegido(carrosDisponibles, carroSeleccionado.getAño());
        } else {
            JOptionPane.showMessageDialog(null, "No se seleccionó un carro. Inténtelo de nuevo.");
        }
    } else {
        JOptionPane.showMessageDialog(null, "No se seleccionó un cliente. Inténtelo de nuevo.");
    }
    break;
                case 3:
                    if (clienteActual != null && carroSeleccionado != null) {
                        clienteActual.verificarHistorialYBeneficio();
                        realizarPago(carroSeleccionado, clienteActual);
                    } else {
                        JOptionPane.showMessageDialog(null, "Primero debe seleccionar un carro y un cliente.");
                    }
                    break;
                case 4:
                    JOptionPane.showMessageDialog(null, "Saliendo, gracias por usar al programa");
            }
        } while (opcion != 4);
    }

    //Metodo para seleccionar un cliente
    private static Cliente seleccionarCliente() {
        String nombre = JOptionPane.showInputDialog("Ingrese su nombre:");
        String inputEdad = JOptionPane.showInputDialog("Ingrese su edad:");
        int edad;
        try {
            //Se verifica que el cliente es mayor de 18 años
            edad = Integer.parseInt(inputEdad);
            while (edad < 18) {
                JOptionPane.showMessageDialog(null, "Debes ser mayor de 18 años para continuar.");
                inputEdad = JOptionPane.showInputDialog("Ingrese su edad:");
                edad = Integer.parseInt(inputEdad);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Edad inválida. Inténtelo de nuevo.");
            return null;  // Devuelve null si la entrada no es válida
        }

        // Se guarda el ID del cliente
        int id = Integer.parseInt(JOptionPane.showInputDialog("Ingrese su ID:"));
        boolean historialCredito = Boolean.parseBoolean(JOptionPane.showInputDialog("¿Tiene historial de crédito? (true/false)"));

        return new Cliente(nombre, edad, id, historialCredito);   
    }

    // Metodo que se usa para mostrar los carros alamacenados en el arreglo de la clase Carro
    private static void visualizarCatalogoCarros(Carro[] carros) {
    StringBuilder mensaje = new StringBuilder("Catalogo de carros:\n");
    for (int i = 0; i < carros.length; i++) {
        if (carros[i] != null) {
            mensaje.append(i + 1).append(". ").append(carros[i].getMarca()).append(" ").append(carros[i].getModelo()).append("\n");
        }else {
            mensaje.append(i + 1).append(". No disponible\n");
        }
    }
    JOptionPane.showMessageDialog(null, mensaje.toString());
}
    
     // Método para realizar un pago usando la clase pago
     private static void realizarPago(Carro carro, Cliente cliente) {
        Pago.realizarPago(carro, cliente);
     }
     
     // Metodo que se usa para no mostrar el carro elegido al cliente en el catalogo
     private static void VisualizarCarrosDisponibles(Carro[] carros, int añoElegido) {
        StringBuilder mensaje = new StringBuilder("Carros disponibles:\n");
         for (int i = 0; i < carros.length; i++) {
            if (carros[i] != null && carros[i].getAño() != añoElegido) {
            mensaje.append(i + 1).append(". ").append(carros[i].getMarca()).append(" ").append(carros[i].getModelo()).append("\n");
            }
         }
    JOptionPane.showMessageDialog(null, mensaje.toString());
    }
     
     /*Metodo que se usa para mostrar el carro elegido por el cliente, se descubre el carro elegido por medio del 
     año de creación */
     private static void auto_elegido(Carro[] carros, int añoElegido) {
         // Variable que tomará la posición que se eliminará del arreglo
        StringBuilder mensaje = new StringBuilder("Carro elegido:\n");
        for (int i = 0; i < carros.length; i++) {
        if (carros[i] != null && carros[i].getAño() == añoElegido) {
            mensaje.append(i + 1).append(". ").append(carros[i].getMarca()).append(" ").append(carros[i].getModelo()).append("\n");
            }
        }
        JOptionPane.showMessageDialog(null, mensaje.toString());
     }
}